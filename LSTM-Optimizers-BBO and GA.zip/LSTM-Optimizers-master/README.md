Let a biogeography-based and GA optimizers train your LSTM recurrent neural network...

# LSTM-Optimizers
Cite as:

Rashid, T., Hassan, M., Mohammed, M. & Fraser, K. (2019), "Improvement of variant adaptable LSTM trained with metaheuristic algorithms for health care analysis", 
in Chakraborty, C. (Ed), Advanced Classification Techniques for Healthcare Analysis, IGI Global, Hershey, PA, Chapter 6, ISBN: 978-1-52257-796-6 DOI: 10.4018/978-1-5225-7796-6 www.igi-global.com/book/advanced-classification-techniques-healthcare-analysis/210213

S. Mirjalili, How effective is the GreyWolf optimizer in training multi-layer perceptrons, Applied Intelligence, In press, 2015, DOI: http://dx.doi.org/10.1007/s10489-014-0645-7
